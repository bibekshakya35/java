package DNAfakeserver.DNAfakeserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DnAfakeserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(DnAfakeserverApplication.class, args);
	}
}

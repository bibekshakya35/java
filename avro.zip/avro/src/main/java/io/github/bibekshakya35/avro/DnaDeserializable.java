package io.github.bibekshakya35.avro;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

/**
 * Created by bibek on 8/7/17.
 */
public class DnaDeserializable {
    public static void main(String [] args) throws IOException,URISyntaxException{
        Schema schema =new Schema.Parser()
                .parse(new File(DnaDeserializable.class.getResource("/schema/dna.avsc").toURI()));
        DatumReader<GenericRecord> datumReader = new GenericDatumReader<GenericRecord>(schema);
        DataFileReader<GenericRecord> dataFileReader = new DataFileReader<GenericRecord>(new File("/home/bibek/bs-workspace/uber/part-00018-of-00025.avro"), datumReader);
        GenericRecord document = null;
        while (dataFileReader.hasNext()) {
            document = dataFileReader.next(document);
            System.out.println(document);
        }
    }
}
